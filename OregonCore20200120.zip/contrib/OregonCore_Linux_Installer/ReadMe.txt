** Please note this has only been tested on ubuntu 16.04 **

OregonCore.py is an installer for Linux based systems (terminals), the installer makes it easier for users install and compile OregonCore.

This installer will automatically, Download and compile the selected source which you have located in the config. (personal branch aswell)
It will download and extract all the Data files that are needed, and also input your Database the only thing that you will have todo is edit your config files

to use the installer edit the config.ini and run the following code.

sudo python3 OregonCore.py

 
