= Oregon Core -- Linux Restarter =

Copyright (C) 2010-2018 OregonCore <https://oregon-core.net/>

Content :
- File "oregon" is an interface to use easier "screen" command.
- File "restarter" is to restart a screen if he stopped.
- install.sh to install oregon in /etc/init.d and restarter in /opt/oregon.

Autor :
- MiLk
