chmod +x oregon restarter
cp oregon /etc/init.d/
cp restarter /opt/oregon/
