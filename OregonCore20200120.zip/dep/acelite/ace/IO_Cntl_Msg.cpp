#include "ace/IO_Cntl_Msg.h"

#if !defined (__ACE_INLINE__)
#include "ace/IO_Cntl_Msg.inl"
#endif /* __ACE_INLINE__ */
