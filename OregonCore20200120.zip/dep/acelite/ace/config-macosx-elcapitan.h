#ifndef ACE_CONFIG_MACOSX_ELCAPITAN_H
#define ACE_CONFIG_MACOSX_ELCAPITAN_H

#include "ace/config-macosx-yosemite.h"

#endif // ACE_CONFIG_MACOSX_ELCAPITAN_H
